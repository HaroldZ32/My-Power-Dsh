import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { createServer as netServer } from 'node:net';
import { spawn, spawnSync } from 'node:child_process';
import { randomUUID, createHash } from 'node:crypto';
import { existsSync, mkdirSync, mkdtempSync, writeFileSync, readFileSync, readdirSync, realpathSync, openSync, closeSync, symlinkSync, utimesSync } from 'node:fs';
import { join, resolve, dirname, basename } from 'node:path';
import { setTimeout as delay } from 'node:timers/promises';
import { messagesTextEvents, messagesToolUseEvents, readWireRequest, writeMessagesSse } from '../skills/dsh-qa/scripts/lib/messages-sse.ts';
import { decodeSessionLog } from '../skills/dsh-qa/scripts/lib/session-evidence.ts';
const mode = process.argv[2] ?? 'all';
assert(['wait-task','wait-mail','wait-steer','wait-steer-step','wait-ended','wait-already'].includes(mode));
const scratch = resolve('.qa-captain-wake');
for (const k of ['HOME', 'DSH_HOME', 'TMPDIR'])
    assert(process.env[k]?.startsWith(scratch + '/'));
const sandbox = mkdtempSync(join(process.env.TMPDIR, 'wake-' + mode + '-')), ws = join(sandbox, 'ws'), home = join(sandbox, 'home'), dshHome = join(sandbox, 'dsh'), profile = join(dshHome, 'profiles', 'w');
for (const d of [ws, home, profile, join(ws, '.mpd')])
    mkdirSync(d, { recursive: true });
const env = { ...process.env, HOME: home, DSH_HOME: dshHome, DEEPSEEK_API_KEY: 'offline-only-wake-fixture' };
// The workspace uses all shipped goal and Team defaults.
const scopeDir = join(profile, 'node_modules', '@mpd-dsh');
mkdirSync(scopeDir, { recursive: true });
symlinkSync(process.cwd(), join(scopeDir, 'mpd'), 'dir');
writeFileSync(join(profile, 'package.json'), JSON.stringify({ name: 'dsh-profile-w', private: true, dependencies: { '@mpd-dsh/mpd': 'link:' + process.cwd() }, dsh: { profile: { bundles: ['@deepseek-ai/dsh-base', '@deepseek-ai/dsh-web-app', '@mpd-dsh/mpd'] } } }));
const marker = 'QA_INTERNAL_MAIL_TEXT';
const providerCalls = [];
let rootStep = 0, notified = false, rootId = '', left = '', right = '', registrationId = '', teamId = '', rpcPrompts = [], eventEvidence = [], error = '', bootExit, rootWaiter;
const isMail = mode.startsWith('mail');
const filter = isMail ? { event: 'mail', from_member: 'M1' } : { task_ids: mode === 'already' ? ['T1'] : ['T1', 'T2'], mode: mode === 'any' ? 'any' : 'all' };
const handle = async (req, res) => {
    let body = '';
    for await (const chunk of req)
        body += chunk;
    const wire = readWireRequest(body);
    const users = wire.messages.filter(m => m.role === 'user').flatMap(m => typeof m.content === 'string' ? [m.content] : (m.content ?? []).filter(p => p.type === 'text').map(p => p.text));
    const event = users.filter(s => s.startsWith('QA_EVENT ')).at(-1);
    const toolCap = wire.toolNames.length > 0;
    let call, actor = 'other';
    if (toolCap && event) {
        actor = 'producer';
        const task = JSON.parse(event.slice('QA_EVENT '.length));
        const start = wire.messages.findLastIndex(m => m.role === 'user' && (m.content === event || Array.isArray(m.content) && m.content.some(b => b?.text === event)));
        const used = wire.messages.slice(start + 1).some(m => m.role === 'assistant');
        if (!used)
            call = task;
    }
    else if (toolCap && users.some(x => x === 'QA_CAPTAIN')) {
        actor = 'captain';
        const last = wire.toolResults.at(-1) ?? '';
        const id = last.match(/\bwake ([0-9a-f-]{36})\b/i)?.[1];
        if (id && !registrationId)
            registrationId = id;
        const seed=[{name:'agent_teams_plan',args:{action:'create',name:'Goal interaction',description:'Wait for ordinary QA events',approval:'required'}},{name:'agent_teams_plan',args:{action:'edit',...(mode==='wait-mail'?{members:[{name:'mail-source',role:'Senior Engineer',description:'First QA mail actor',prompt:'End the zero-work startup turn.'},{name:'other-source',role:'Senior Engineer',description:'Second QA mail actor',prompt:'End the zero-work startup turn.'}]}:{}),tasks:['one','two','other'].map(subject=>({subject,description:'Controlled input',independent:true,kind:'requirement'}))}},{name:'agent_teams_plan',args:{action:'approve'}},{name:'mpd_goal_status',args:{}}];
        if(rootStep<seed.length)call=seed[rootStep];
        else if(rootStep===seed.length){if(mode==='wait-already'){const b=currentBoard();commit(b.teamId,'T1');commit(b.teamId,'T2')};call={name:'agent_teams_control',args:{action:'wake',wake:{action:'wait',...(mode==='wait-mail'?{event:'mail',from_member:'M1'}:{task_ids:['T1','T2'],mode:'all'})}}};}
        else if(rootStep===seed.length+1)call=mode==='wait-mail'?{name:'agent_teams_mail',args:{action:'unread'}}:{name:'agent_teams_plan',args:{action:'status'}};
        else if(rootStep===seed.length+2)call={name:'mpd_goal_status',args:{}};
        else if(rootStep===seed.length+3)call={name:'agent_teams_control',args:{action:'wake',wake:{action:'status'}}};
        else if(users.some(s=>s.includes('QA_STEER_NEXT'))&&!notified){notified=true;call={name:'agent_teams_plan',args:{action:'status'}}};
        if(!call)await delay(350);
        rootStep++;
    }
    providerCalls.push({ time: Date.now(), actor, tool: call?.name ?? null });
    writeMessagesSse(res, call ? messagesToolUseEvents('wakeqa_' + providerCalls.length, call.name, call.args) : messagesTextEvents('QA turn finished.'));
};
const server = createServer((req, res) => void handle(req, res).catch(e => { res.writeHead(500); res.end(); console.error(e.message); }));
await new Promise(r => server.listen(0, '127.0.0.1', r));
const overlay = join(sandbox, 'route.yml');
writeFileSync(overlay, '- id: llm-deepseek\n  config:\n    baseURL: http://127.0.0.1:' + server.address().port + '/v1\n    apiKeyEnv: DEEPSEEK_API_KEY\n');
const ns = netServer();
await new Promise(r => ns.listen(0, '127.0.0.1', r));
const port = ns.address().port;
await new Promise(r => ns.close(r));
const logPath = join(sandbox, 'boot.log');
const fd = openSync(logPath, 'w');
const host = spawn('dsh', ['--profile', 'w', '--patch', overlay, '--port', String(port), '--no-open'], { cwd: ws, env, stdio: ['ignore', fd, fd] });
const exited = new Promise(r => host.on('exit', (c, s) => { bootExit = { code: c, signal: s }; r(); }));
let cookie = '';
const wait = async (name, fn, ms = 12000) => { const until = Date.now() + ms; while (Date.now() < until) {
    const value = await fn();
    if (value)
        return value;
    if (bootExit)
        throw Error('host exited during ' + name + ' ' + JSON.stringify(bootExit));
    await delay(60);
} throw Error('timeout ' + name); };
const rpc = async (method, req) => { const res = await fetch('http://127.0.0.1:' + port + '/api/' + method, { method: 'POST', headers: { 'content-type': 'application/json', cookie }, body: JSON.stringify({ type: 'client-request', rpcId: randomUUID(), method, payload: { args: { request: req } } }), signal: AbortSignal.timeout(12000) }); const j = await res.json(); assert.equal(res.status, 200); if (j.error || j.result?.ok === false)
    throw Error('RPC ' + method + ' ' + JSON.stringify(j.error ?? j.result.error).slice(0, 260)); return j.result?.value ?? j.result; };
const logFor = id => { const dir = join(dshHome, 'sessions'); if (!existsSync(dir))
    return []; const f = readdirSync(dir, { recursive: true }).find(f => f.includes('/' + id + '/') && f.endsWith('.jsonl.zstd')); if (!f)
    return []; const txt = decodeSessionLog(join(dir, f)).text; return txt.trim().split('\n').filter(Boolean).map(l => JSON.parse(l)); };
const ends = id => logFor(id).filter(e => e.type === 'turn/end');
const starts = id => logFor(id).filter(e => e.type === 'turn/start');
const prompt = async (id, text) => { rpcPrompts.push({ session: id, time: Date.now(), type: id === rootId ? 'initial-captain-prompt' : 'producer-action' }); await rpc('session/prompt', { requestId: randomUUID(), sessionId: id, mode: 'queue', content: [{ type: 'text', text }] }); };
const produce = async (id, args, label) => {
    if (process.env.WAKE_FIXTURE === 'external') {
        const before = Date.now();
        const x = spawnSync(resolve('.toolchain/node_modules/.bin/bun'), [join(scratch, 'commit-event.mjs'), ws, teamId, id, JSON.stringify(args)], { env, encoding: 'utf8' });
        assert.equal(x.status, 0, x.stderr);
        const receipt = JSON.parse(x.stdout);
        eventEvidence.push({ label, source: 'separate process, production store commit', actor: id, called: before, resultTime: receipt.time, receipt, captainTurnCount: starts(rootId).length });
        return;
    }
    const name = args.task_id ? 'agent_teams_task' : 'agent_teams_mail';
    const before = ends(id).length;
    const t = Date.now();
    await prompt(id, 'QA_EVENT ' + JSON.stringify({ name, args }));
    await wait('producer ' + label, () => ends(id).length > before);
    const ev = logFor(id), call = ev.filter(e => e.type === 'tool/call').at(-1), msg = ev.find(e => e.type === 'tool/result' && e.data.message.toolCallId === call?.data.callId);
    const text = msg?.data.message.content.map(p => p.text).join('');
    assert.equal(call?.data.name, name, 'producer did not call ' + name);
    assert(msg && msg.data.message.isError === false, 'producer failed ' + String(text));
    eventEvidence.push({ label, actor: id, prompted: t, call: call.data.callId, called: call.time, resultTime: msg.time, receipt: text.split('\n')[0].replaceAll(marker, '[mail fixture]'), captainTurnCount: starts(rootId).length });
};
const complete = async (id, task) => produce(id, { action: 'complete', task_id: task, note: 'QA event' }, task);
const mail = async (id, to, label) => produce(id, { action: 'send', to, subject: marker + '_SUBJECT', body: marker + '_BODY' }, label);
const pause = ms => delay(ms);
const wakeTexts = e => e.filter(r => r.type === 'user/message' && r.data.content?.some(p => typeof p.text === 'string' && !p.text.startsWith('<system-reminder>') && p.text.includes(registrationId) && registrationId.length === 36)).map(r => ({ time: r.time, data: r.data }));
const currentBoard=()=>{const d=join(ws,'.mpd/team/teams');return existsSync(d)?readdirSync(d).filter(f=>f.endsWith('.json')).map(f=>JSON.parse(readFileSync(join(d,f),'utf8'))).find(b=>b.name==='Goal interaction'):undefined};
const commit=(id,action)=>{const run=spawnSync(resolve('.toolchain/node_modules/.bin/bun'),[join(scratch,'condition-event.mjs'),ws,id,action],{env,encoding:'utf8'});assert.equal(run.status,0,run.stderr);const receipt=JSON.parse(run.stdout);eventEvidence.push(receipt);return receipt};
const args=c=>typeof c.data.arguments==='string'?JSON.parse(c.data.arguments):c.data.arguments;
const waitCall=()=>logFor(rootId).find(e=>e.type==='tool/call'&&e.data.name==='agent_teams_control'&&args(e).wake?.action==='wait');
const paired=id=>logFor(rootId).find(e=>e.type==='tool/result'&&e.data.message.toolCallId===id);

let quietWindow, final, stopState;
try {
    await wait('web-ready', async () => { const token = readFileSync(logPath, 'utf8').match(/token=([A-Za-z0-9_-]+)/)?.[1]; if (!token)
        return false; try {
        const res = await fetch('http://127.0.0.1:' + port + '/?token=' + token, { redirect: 'manual', signal: AbortSignal.timeout(1200) });
        cookie = res.headers.getSetCookie().map(h => h.split(';')[0]).join('; ');
        return Boolean(cookie);
    }
    catch {
        return false;
    } }, 30000);
    for (const dest of ['root', 'left', 'right']) {
        const ans = await rpc('session/create', { cwd: ws, agentPreset: 'mpd' });
        assert(ans.sessionId);
        if (dest === 'root')
            rootId = ans.sessionId;
        else if (dest === 'left')
            left = ans.sessionId;
        else
            right = ans.sessionId;
    }
    await prompt(rootId,'QA_CAPTAIN');const call=await wait('initial real wait dispatch',waitCall,20000);teamId=currentBoard().teamId;const callId=call.data.callId;
    const ev0=logFor(rootId);const durableGoal=ev0.filter(e=>e.type==='goal/change').at(-1)?.data;assert(durableGoal?.goal.phase==='active','default approval goal did not arm');
    const count=()=>logFor(rootId).filter(e=>e.type==='user/message'&&e.data.source?.kind==='goal').length;
    if(mode!=='wait-already'){
      await pause(500);if(paired(callId))throw Error('wait already returned before any event: '+JSON.stringify(paired(callId).data.message.content).slice(0,900));
      if(mode==='wait-mail'){commit(teamId,'M2>captain');commit(teamId,'M1>M2')}else{commit(teamId,'T3');commit(teamId,'T1')}
      await pause(1800);const beforeWake=Date.now();assert(!paired(callId),'partial or unrelated event released wait');
      quietWindow={from:call.time,to:beforeWake,captainProviderRequests:providerCalls.filter(p=>p.actor==='captain'&&p.time>call.time&&p.time<=beforeWake).length,goalRoundsBefore:ev0.filter(e=>e.type==='user/message'&&e.data.source?.kind==='goal').length,goalRoundsNow:count(),turns:starts(rootId).length,completedTurns:ends(rootId).length};assert.equal(quietWindow.captainProviderRequests,0);assert.equal(quietWindow.goalRoundsNow,quietWindow.goalRoundsBefore);assert(!ends(rootId).some(e=>e.data.turn===call.data.turn));
      if(mode.startsWith('wait-steer')){const at=Date.now();await rpc('session/prompt',{requestId:randomUUID(),sessionId:rootId,mode:mode==='wait-steer-step'?'steer':'queue',content:[{type:'text',text:'QA_STEER_NEXT: show the board status now.'}]});eventEvidence.push({action:mode==='wait-steer-step'?'human-steer':'human-queue',at})}else commit(teamId,mode==='wait-mail'?'M1>captain':mode==='wait-ended'?'end':'T2');
    }
    const got=await wait('original wait tool result',()=>paired(callId),7000);const text=got.data.message.content.map(c=>c.text).join('');assert(!got.data.message.isError,text);assert.match(text,mode==='wait-ended'?/ended/:mode.startsWith('wait-steer')?/steered/:/matched/);eventEvidence.push({label:'wait-result',at:got.time,turn:got.data.turn,id:callId,text});
    if(mode.startsWith('wait-steer'))await wait('steering reached a useful step',()=>logFor(rootId).some(e=>e.type==='tool/call'&&e.seq>got.seq&&e.data.name==='agent_teams_plan'),12000);
    else await wait('same-turn outcome consumed',()=>logFor(rootId).some(e=>e.type==='tool/result'&&e.seq>got.seq&&e.data.turn===call.data.turn));
    await wait('status after wait',()=>logFor(rootId).some(e=>e.type==='tool/call'&&e.seq>got.seq&&e.data.name==='agent_teams_control'&&args(e).wake?.action==='status'),3000);await pause(150);
    const ev=logFor(rootId);assert(!ev.some(e=>e.type==='user/message'&&e.data.source?.kind==='mpd-team-wake'));eventEvidence.push({label:'goal unchanged',goal:ev.filter(e=>e.type==='goal/change').at(-1)?.data.goal,goalChangeCount:ev.filter(e=>e.type==='goal/change').length,humanSteer:ev.filter(e=>e.type==='user/message'&&e.data.content?.some(p=>p.text?.includes('QA_STEER_NEXT')&&!p.text.startsWith('<system-reminder>'))).map(e=>({at:e.time,seq:e.seq,source:e.data.source?.kind})),postResult:ev.filter(e=>e.seq>got.seq&&e.type==='tool/call').map(e=>({seq:e.seq,turn:e.data.turn,name:e.data.name,args:args(e)}))});

}
catch (e) {
    error = e.message.slice(0, 1450);
}
finally {
    const ev = rootId ? logFor(rootId) : [];
    const normalize = r => ({ seq: r.seq, at: r.time, turn: r.data.turn, reason: r.data.reason?.kind });
    const calls = ev.filter(r => r.type === 'tool/call').map(c => { const reply = ev.find(r => r.type === 'tool/result' && r.data.message.toolCallId === c.data.callId); return { id: c.data.callId, seq: c.seq, turn: c.data.turn, tool:c.data.name, calledAt:c.time, args:typeof c.data.arguments === 'string' ? JSON.parse(c.data.arguments) : c.data.arguments, completedAt: reply?.time, isError: reply?.data.message.isError, text: reply?.data.message.content.map(p => p.text).join('').slice(0, 850) }; });
    const texts = wakeTexts(ev).map(r => ({ at: r.time, source: r.data.source?.kind, content: r.data.content?.filter(p => p.type === 'text').map(p => p.text.slice(0, 500)) }));
    final = { mode, ok: !error, error, host: '0.2.2-rc.5', dist: createHash('sha256').update(readFileSync('packages/mpd-team-core-plugin/dist/index.js')).digest('hex'), teamId, captain: rootId, actors: { M1: left, M2: right }, quietWindow, goals: ev.filter(e => e.type === 'goal/change').length, requests: providerCalls, rpcPrompts, events: eventEvidence, captainTurns: { starts: ev.filter(e => e.type === 'turn/start').map(normalize), ends: ev.filter(e => e.type === 'turn/end').map(normalize) }, toolReceipts: calls, wakes: texts };
    writeFileSync(join(scratch, mode + '.json'), JSON.stringify(final, null, 2));
    writeFileSync(join(scratch, mode + '-sandbox-path'), sandbox);
    host.kill('SIGTERM');
    await Promise.race([exited, delay(1500)]);
    if (!bootExit) {
        host.kill('SIGKILL');
        await exited;
    }
    closeSync(fd);
    await new Promise(r => server.close(r));
}
console.log(JSON.stringify({ mode, error, result: final.toolReceipts.map(r => [r.turn, r.args.wake?.action??r.args.action, r.text?.slice(0, 170)]), events: final.events.map(e => e.label), turns: final.captainTurns, wakes: final.wakes, quietWindow }));
process.exitCode = error ? 1 : 0;

import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { createServer as netServer } from 'node:net';
import { spawn, spawnSync } from 'node:child_process';
import { randomUUID, createHash } from 'node:crypto';
import { existsSync, mkdirSync, mkdtempSync, writeFileSync, readFileSync, readdirSync, realpathSync, openSync, closeSync, symlinkSync, utimesSync } from 'node:fs';
import { join, resolve, dirname, basename } from 'node:path';
import { setTimeout as delay } from 'node:timers/promises';
import { messagesTextEvents, messagesToolUseEvents, readWireRequest, writeMessagesSse } from '../skills/dsh-qa/scripts/lib/messages-sse.ts';
import { decodeSessionLog } from '../skills/dsh-qa/scripts/lib/session-evidence.ts';
const mode = process.argv[2] ?? 'all';
assert(['goal-armed','goal-only'].includes(mode));
const scratch = resolve('.qa-captain-wake');
for (const k of ['HOME', 'DSH_HOME', 'TMPDIR'])
    assert(process.env[k]?.startsWith(scratch + '/'));
const sandbox = mkdtempSync(join(process.env.TMPDIR, 'wake-' + mode + '-')), ws = join(sandbox, 'ws'), home = join(sandbox, 'home'), dshHome = join(sandbox, 'dsh'), profile = join(dshHome, 'profiles', 'w');
for (const d of [ws, home, profile, join(ws, '.mpd')])
    mkdirSync(d, { recursive: true });
const env = { ...process.env, HOME: home, DSH_HOME: dshHome, DEEPSEEK_API_KEY: 'offline-only-wake-fixture' };
// The workspace uses all shipped goal and Team defaults.
const scopeDir = join(profile, 'node_modules', '@mpd-dsh');
mkdirSync(scopeDir, { recursive: true });
symlinkSync(process.cwd(), join(scopeDir, 'mpd'), 'dir');
writeFileSync(join(profile, 'package.json'), JSON.stringify({ name: 'dsh-profile-w', private: true, dependencies: { '@mpd-dsh/mpd': 'link:' + process.cwd() }, dsh: { profile: { bundles: ['@deepseek-ai/dsh-base', '@deepseek-ai/dsh-web-app', '@mpd-dsh/mpd'] } } }));
const marker = 'QA_INTERNAL_MAIL_TEXT';
const providerCalls = [];
let rootStep = 0, notified = false, rootId = '', left = '', right = '', registrationId = '', teamId = '', rpcPrompts = [], eventEvidence = [], error = '', bootExit, rootWaiter;
const isMail = mode.startsWith('mail');
const filter = isMail ? { event: 'mail', from_member: 'M1' } : { task_ids: mode === 'already' ? ['T1'] : ['T1', 'T2'], mode: mode === 'any' ? 'any' : 'all' };
const handle = async (req, res) => {
    let body = '';
    for await (const chunk of req)
        body += chunk;
    const wire = readWireRequest(body);
    const users = wire.messages.filter(m => m.role === 'user').flatMap(m => typeof m.content === 'string' ? [m.content] : (m.content ?? []).filter(p => p.type === 'text').map(p => p.text));
    const event = users.filter(s => s.startsWith('QA_EVENT ')).at(-1);
    const toolCap = wire.toolNames.length > 0;
    let call, actor = 'other';
    if (toolCap && event) {
        actor = 'producer';
        const task = JSON.parse(event.slice('QA_EVENT '.length));
        const start = wire.messages.findLastIndex(m => m.role === 'user' && (m.content === event || Array.isArray(m.content) && m.content.some(b => b?.text === event)));
        const used = wire.messages.slice(start + 1).some(m => m.role === 'assistant');
        if (!used)
            call = task;
    }
    else if (toolCap && users.some(x => x === 'QA_CAPTAIN')) {
        actor = 'captain';
        const last = wire.toolResults.at(-1) ?? '';
        const id = last.match(/\bwake ([0-9a-f-]{36})\b/i)?.[1];
        if (id && !registrationId)
            registrationId = id;
        const steps=[{name:'agent_teams_plan',args:{action:'create',name:'Goal interaction',description:'Wait for the two real QA rows',approval:'required'}},{name:'agent_teams_plan',args:{action:'edit',tasks:[{subject:'first',description:'QA event one',independent:true,kind:'requirement'},{subject:'second',description:'QA event two',independent:true,kind:'requirement'}]}},{name:'agent_teams_plan',args:{action:'approve'}}];
        if(mode==='goal-armed')steps.push({name:'agent_teams_control',args:{action:'wake',wake:{action:'arm',task_ids:['T1','T2'],mode:'all'}}});
        if(rootStep<steps.length)call=steps[rootStep];
        else if(registrationId&&users.some(u=>u.startsWith('Team wake '+registrationId))&&!notified){notified=true;call={name:'agent_teams_control',args:{action:'wake',wake:{action:'status',id:registrationId}}};}
        if(!call)await delay(250);
        rootStep++;
    }
    providerCalls.push({ time: Date.now(), actor, tool: call?.name ?? null });
    writeMessagesSse(res, call ? messagesToolUseEvents('wakeqa_' + providerCalls.length, call.name, call.args) : messagesTextEvents('QA turn finished.'));
};
const server = createServer((req, res) => void handle(req, res).catch(e => { res.writeHead(500); res.end(); console.error(e.message); }));
await new Promise(r => server.listen(0, '127.0.0.1', r));
const overlay = join(sandbox, 'route.yml');
writeFileSync(overlay, '- id: llm-deepseek\n  config:\n    baseURL: http://127.0.0.1:' + server.address().port + '/v1\n    apiKeyEnv: DEEPSEEK_API_KEY\n');
const ns = netServer();
await new Promise(r => ns.listen(0, '127.0.0.1', r));
const port = ns.address().port;
await new Promise(r => ns.close(r));
const logPath = join(sandbox, 'boot.log');
const fd = openSync(logPath, 'w');
const host = spawn('dsh', ['--profile', 'w', '--patch', overlay, '--port', String(port), '--no-open'], { cwd: ws, env, stdio: ['ignore', fd, fd] });
const exited = new Promise(r => host.on('exit', (c, s) => { bootExit = { code: c, signal: s }; r(); }));
let cookie = '';
const wait = async (name, fn, ms = 12000) => { const until = Date.now() + ms; while (Date.now() < until) {
    const value = await fn();
    if (value)
        return value;
    if (bootExit)
        throw Error('host exited during ' + name + ' ' + JSON.stringify(bootExit));
    await delay(60);
} throw Error('timeout ' + name); };
const rpc = async (method, req) => { const res = await fetch('http://127.0.0.1:' + port + '/api/' + method, { method: 'POST', headers: { 'content-type': 'application/json', cookie }, body: JSON.stringify({ type: 'client-request', rpcId: randomUUID(), method, payload: { args: { request: req } } }), signal: AbortSignal.timeout(12000) }); const j = await res.json(); assert.equal(res.status, 200); if (j.error || j.result?.ok === false)
    throw Error('RPC ' + method + ' ' + JSON.stringify(j.error ?? j.result.error).slice(0, 260)); return j.result?.value ?? j.result; };
const logFor = id => { const dir = join(dshHome, 'sessions'); if (!existsSync(dir))
    return []; const f = readdirSync(dir, { recursive: true }).find(f => f.includes('/' + id + '/') && f.endsWith('.jsonl.zstd')); if (!f)
    return []; const txt = decodeSessionLog(join(dir, f)).text; return txt.trim().split('\n').filter(Boolean).map(l => JSON.parse(l)); };
const ends = id => logFor(id).filter(e => e.type === 'turn/end');
const starts = id => logFor(id).filter(e => e.type === 'turn/start');
const prompt = async (id, text) => { rpcPrompts.push({ session: id, time: Date.now(), type: id === rootId ? 'initial-captain-prompt' : 'producer-action' }); await rpc('session/prompt', { requestId: randomUUID(), sessionId: id, mode: 'queue', content: [{ type: 'text', text }] }); };
const produce = async (id, args, label) => {
    if (process.env.WAKE_FIXTURE === 'external') {
        const before = Date.now();
        const x = spawnSync(resolve('.toolchain/node_modules/.bin/bun'), [join(scratch, 'commit-event.mjs'), ws, teamId, id, JSON.stringify(args)], { env, encoding: 'utf8' });
        assert.equal(x.status, 0, x.stderr);
        const receipt = JSON.parse(x.stdout);
        eventEvidence.push({ label, source: 'separate process, production store commit', actor: id, called: before, resultTime: receipt.time, receipt, captainTurnCount: starts(rootId).length });
        return;
    }
    const name = args.task_id ? 'agent_teams_task' : 'agent_teams_mail';
    const before = ends(id).length;
    const t = Date.now();
    await prompt(id, 'QA_EVENT ' + JSON.stringify({ name, args }));
    await wait('producer ' + label, () => ends(id).length > before);
    const ev = logFor(id), call = ev.filter(e => e.type === 'tool/call').at(-1), msg = ev.find(e => e.type === 'tool/result' && e.data.message.toolCallId === call?.data.callId);
    const text = msg?.data.message.content.map(p => p.text).join('');
    assert.equal(call?.data.name, name, 'producer did not call ' + name);
    assert(msg && msg.data.message.isError === false, 'producer failed ' + String(text));
    eventEvidence.push({ label, actor: id, prompted: t, call: call.data.callId, called: call.time, resultTime: msg.time, receipt: text.split('\n')[0].replaceAll(marker, '[mail fixture]'), captainTurnCount: starts(rootId).length });
};
const complete = async (id, task) => produce(id, { action: 'complete', task_id: task, note: 'QA event' }, task);
const mail = async (id, to, label) => produce(id, { action: 'send', to, subject: marker + '_SUBJECT', body: marker + '_BODY' }, label);
const pause = ms => delay(ms);
const wakeTexts = e => e.filter(r => r.type === 'user/message' && r.data.content?.some(p => typeof p.text === 'string' && !p.text.startsWith('<system-reminder>') && p.text.includes(registrationId) && registrationId.length === 36)).map(r => ({ time: r.time, data: r.data }));
let quietWindow, final, stopState;
try {
    await wait('web-ready', async () => { const token = readFileSync(logPath, 'utf8').match(/token=([A-Za-z0-9_-]+)/)?.[1]; if (!token)
        return false; try {
        const res = await fetch('http://127.0.0.1:' + port + '/?token=' + token, { redirect: 'manual', signal: AbortSignal.timeout(1200) });
        cookie = res.headers.getSetCookie().map(h => h.split(';')[0]).join('; ');
        return Boolean(cookie);
    }
    catch {
        return false;
    } }, 30000);
    for (const dest of ['root', 'left', 'right']) {
        const ans = await rpc('session/create', { cwd: ws, agentPreset: 'mpd' });
        assert(ans.sessionId);
        if (dest === 'root')
            rootId = ans.sessionId;
        else if (dest === 'left')
            left = ans.sessionId;
        else
            right = ans.sessionId;
    }
    await prompt(rootId,'QA_CAPTAIN');await wait('first yielded turn',()=>ends(rootId).length>0,18000);
    const getTeam=()=>{const d=join(ws,'.mpd/team/teams');return readdirSync(d).filter(f=>f.endsWith('.json')).map(f=>JSON.parse(readFileSync(join(d,f),'utf8'))).find(b=>b.name==='Goal interaction')};
    const board=getTeam();assert(board,'ordinary approval returned no board');teamId=board.teamId;const gs=logFor(rootId).filter(e=>e.type==='goal/change');assert(gs.length>0,'ordinary approval produced no real goal');
    const preStart=ends(rootId)[0].time;await pause(1800);const tw=starts(rootId);const now=Date.now();quietWindow={from:preStart,to:now,captainRequests:providerCalls.filter(p=>p.actor==='captain'&&p.time>preStart).length,turnsStartedBeforeEvent:tw.length};
    const run=spawnSync(resolve('.toolchain/node_modules/.bin/bun'),[join(scratch,'goal-event.mjs'),ws,teamId],{env,encoding:'utf8'});assert.equal(run.status,0,run.stderr);eventEvidence.push(...JSON.parse(run.stdout));
    if(mode==='goal-armed')await wait('original captain consumes condition',()=>wakeTexts(logFor(rootId)).length>=1,12000);
    await pause(1800);const last=logFor(rootId),wake=wakeTexts(last);assert.equal(wake.length,mode==='goal-armed'?1:0);assert.equal(rpcPrompts.filter(p=>p.session===rootId).length,1);
    const boardAfter=getTeam();eventEvidence.push({label:'final board',endedAt:boardAfter.endedAt,reason:boardAfter.archivedReason,rows:boardAfter.tasks.map(t=>[t.id,t.status])});
    eventEvidence.push({label:'goal observations',changes:last.filter(e=>e.type==='goal/change').map(e=>({at:e.time,data:e.data})),turnCauses:last.filter(e=>e.type==='user/message'&&!e.data.content?.some(p=>p.text?.startsWith('<system-reminder>'))).map(e=>({turn:e.data.turn,at:e.time,source:e.data.source?.kind,goalText:e.data.content?.some(p=>/goal|continuation/i.test(p.text??''))})),goalDomainEventTypes:[...new Set(last.filter(e=>e.type.includes('goal')).map(e=>e.type))]});

}
catch (e) {
    error = e.message.slice(0, 1450);
}
finally {
    const ev = rootId ? logFor(rootId) : [];
    const normalize = r => ({ seq: r.seq, at: r.time, turn: r.data.turn, reason: r.data.reason?.kind });
    const calls = ev.filter(r => r.type === 'tool/call').map(c => { const reply = ev.find(r => r.type === 'tool/result' && r.data.message.toolCallId === c.data.callId); return { id: c.data.callId, seq: c.seq, turn: c.data.turn, args: typeof c.data.arguments === 'string' ? JSON.parse(c.data.arguments) : c.data.arguments, completedAt: reply?.time, isError: reply?.data.message.isError, text: reply?.data.message.content.map(p => p.text).join('').slice(0, 850) }; });
    const texts = wakeTexts(ev).map(r => ({ at: r.time, source: r.data.source?.kind, content: r.data.content?.filter(p => p.type === 'text').map(p => p.text.slice(0, 500)) }));
    final = { mode, ok: !error, error, host: '0.2.2-rc.5', dist: createHash('sha256').update(readFileSync('packages/mpd-team-core-plugin/dist/index.js')).digest('hex'), teamId, captain: rootId, actors: { M1: left, M2: right }, quietWindow, goals: ev.filter(e => e.type === 'goal/change').length, requests: providerCalls, rpcPrompts, events: eventEvidence, captainTurns: { starts: ev.filter(e => e.type === 'turn/start').map(normalize), ends: ev.filter(e => e.type === 'turn/end').map(normalize) }, toolReceipts: calls, wakes: texts };
    writeFileSync(join(scratch, mode + '.json'), JSON.stringify(final, null, 2));
    writeFileSync(join(scratch, mode + '-sandbox-path'), sandbox);
    host.kill('SIGTERM');
    await Promise.race([exited, delay(1500)]);
    if (!bootExit) {
        host.kill('SIGKILL');
        await exited;
    }
    closeSync(fd);
    await new Promise(r => server.close(r));
}
console.log(JSON.stringify({ mode, error, result: final.toolReceipts.map(r => [r.turn, r.args.wake?.action??r.args.action, r.text?.slice(0, 170)]), events: final.events.map(e => e.label), turns: final.captainTurns, wakes: final.wakes, quietWindow }));
process.exitCode = error ? 1 : 0;

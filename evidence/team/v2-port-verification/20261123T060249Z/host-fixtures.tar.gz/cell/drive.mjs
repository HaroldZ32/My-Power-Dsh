import { closeSync, existsSync, mkdirSync, openSync, readFileSync, readdirSync, renameSync, rmdirSync, unlinkSync, writeFileSync } from 'node:fs';
import { createServer } from 'node:http';
import { spawn } from 'node:child_process';
import { join, resolve } from 'node:path';
import { setTimeout as delay } from 'node:timers/promises';
import { createSandbox, installProfile, useStubRoute, isolationStep } from '../skills/dsh-qa/scripts/extension-isolation.ts';
import { messagesToolUseEvents, messagesTextEvents, readWireRequest, writeMessagesSse } from '../skills/dsh-qa/scripts/lib/messages-sse.ts';
import { probeOverlay } from '../skills/dsh-qa/scripts/cellwork-command.ts';
import { decodeSessionLog } from '../skills/dsh-qa/scripts/lib/session-evidence.ts';
const mode = process.argv[2] || 'baseline';
const root = resolve('.qa-v2-spawn');
if (!['defaults', 'baseline', 'loop-fault', 'turn-end', 'provider-error', 'persistent-error', 'restart'].includes(mode))
    throw Error('unsupported probe mode');
for (const key of ['HOME', 'DSH_HOME', 'TMPDIR'])
    if (!process.env[key]?.startsWith(root + '/'))
        throw Error(key + ' must be a dedicated child of ' + root);
const fixture = createSandbox('v2-' + mode);
const { sandbox, dshHome, ws, env } = fixture;
const temp = name => join(sandbox, name);
const read = file => JSON.parse(readFileSync(file, 'utf8'));
const dirs = path => existsSync(path) ? readdirSync(path) : [];
const scan = (dir, match) => readdirSync(dir, { recursive: true }).filter(path => match.test(path)).map(path => join(dir, path));
const requirements = '# QA requirements\n## Goal\nObserve actual child dispatch.\n## Non-goals\nNo product changes.\n## Users / consumers\nQA operator.\n## Constraints\nUse only this isolated workspace.\n## Acceptance criteria\nThe assigned worker closes the receipt task.\n## Open questions\nNone.\n';
const tasks = [{ key: 'worker-receipt', subject: 'QA worker receipt', description: 'Close this assigned QA task; no file edits.', kind: 'work', ownerRole: 'Senior Engineer', writeScopes: ['receipt.txt'], blockedBy: [], inputs: [], verify: true }, { key: 'review-receipt', subject: 'QA reviewer receipt', description: 'Close this assigned QA review; no file edits.', kind: 'review', ownerRole: 'Reviewer', writeScopes: [], blockedBy: ['worker-receipt'], inputs: [], verify: false }];
const mortality = ['turn-end', 'provider-error', 'persistent-error', 'restart'].includes(mode);
if (mortality)
    tasks.splice(0, 2, ...['Alpha', 'Beta'].map(label => ({ key: 'worker-' + label.toLowerCase(), subject: 'QA worker ' + label, description: 'Claim this assigned ticket. Remain available for a captain recovery message.', kind: 'requirement', ownerRole: 'Senior Engineer', member: 'worker-' + label, blockedBy: [], inputs: [], verify: false })));
const recordDir = join(ws, '.mpd', 'cellwork');
const boardDir = join(ws, '.mpd', 'team', 'teams');
const cell = () => { const id = dirs(recordDir).find(k => k.startsWith('cell-')); return id ? read(join(recordDir, id, 'state.json')) : null; };
const boards = () => dirs(boardDir).filter(f => f.endsWith('.json')).map(f => read(join(boardDir, f)));
const redactBoard = board => ({ teamId: board.teamId, endedAt: board.endedAt, members: board.members.map(m => ({ name: m.name, id: m.id, executorRef: m.executorRef, role: m.role })), tasks: board.tasks.map(t => ({ id: t.id, subject: t.subject, owner: t.owner, claimant: t.claimant ?? t.claimedBy ?? null, status: t.status, attempt: t.attempt ?? 0, revision: t.revision })) });
const trace = [];
const act = (name, args = {}) => ({ name, args });
let injected, cleared = false;
const snapshots = [];
const sequence = [];
const observed = new Set();
let resumed = false;
let captainCalls = 0;
let activationCalls = 0;
const server = createServer(async (req, res) => {
    try {
        let body = '';
        for await (const part of req)
            body += part;
        const wire = readWireRequest(body);
        const users = wire.messages.filter(m => m.role === 'user').flatMap(m => typeof m.content === 'string' ? [m.content] : m.content.filter(x => x.type === 'text').map(x => x.text));
        const prompts = users.filter(s => !s.startsWith('<system-reminder>') && !s.startsWith('Time sampled'));
        const assignment = prompts.map(s => s.match(/You have been assigned shared task (\w+): ([^\n]+)/)).filter(Boolean).at(-1);
        const captain = prompts.some(s => s.includes('QA-BOOT-CAPTAIN') || s.startsWith('[mpd-cellwork] CELLWORK MODE IS ACTIVE')) && !prompts.some(s => s.includes('You are a team member.'));
        const st = cell();
        const br = boards();
        const rows = br.flatMap(b => b.tasks);
        let next = null;
        if (wire.toolNames.length === 0 || prompts.some(s => s.startsWith('Generate the session title'))) {
            next = null;
        }
        else if (captain && ++captainCalls < 30 && trace.length < 100) {
            await delay(180);
            if (!st || !st.startedAt) {
                if (st)
                    next = act('cellwork_start');
            }
            else if (!st.activatedRevision && existsSync(join(recordDir, st.cellId, 'split', '1.json'))) {
                if (mode === 'loop-fault' && !injected) {
                    injected = join(ws, '.mpd', 'verify', 'loops');
                    const saved = temp('saved-loops');
                    if (injected !== resolve(ws, '.mpd/verify/loops') || !injected.startsWith(sandbox + '/') || existsSync(saved))
                        throw Error('invalid fixture path');
                    if (existsSync(injected))
                        renameSync(injected, saved);
                    writeFileSync(injected, 'QA-LOOP-DIRECTORY-FAULT', { flag: 'wx' });
                }
                else if (injected && !cleared) {
                    if (injected !== resolve(ws, '.mpd/verify/loops') || readFileSync(injected, 'utf8') !== 'QA-LOOP-DIRECTORY-FAULT')
                        throw Error('invalid fixture path');
                    snapshots.push({ event: 'partial-before-retry', board: br.map(redactBoard), partial: st.activationInFlight });
                    unlinkSync(injected);
                    if (existsSync(temp('saved-loops')))
                        renameSync(temp('saved-loops'), injected);
                    cleared = true;
                }
                if (++activationCalls <= 3)
                    next = act('cellwork_activate');
            }
            else if (st.activatedRevision && mortality) {
                if (observed.size < 2)
                    next = act('cellwork_status');
                else if (mode !== 'restart' || resumed) {
                    const steps = [act('cellwork_status'), act('cellwork_supervise'), act('cellwork_dispatch'), act('cellwork_send', { to: 'worker-Alpha', subject: 'QA-RECOVERY', body: 'QA-RECOVERY: finish your existing ticket' }), act('cellwork_send', { to: 'worker-Beta', subject: 'QA-RECOVERY', body: 'QA-RECOVERY: finish your existing ticket' }), act('cellwork_supervise'), act('cellwork_status')];
                    next = steps[sequence.length] ?? null;
                    if (next) {
                        sequence.push(next);
                        snapshots.push({ event: next.name, board: br.map(redactBoard) });
                    }
                }
            }
            else if (!st.activatedRevision || rows.some(t => t.subject === 'QA worker receipt' && t.status !== 'completed'))
                next = act('cellwork_dispatch');
        }
        else if (assignment) {
            const [, id, subject] = assignment;
            const row = rows.findLast(t => t.id === id && t.subject === subject);
            if (row && !['completed', 'failed', 'cancelled'].includes(row.status) && wire.toolResults.length < 5) {
                if (subject.includes('Requirements interview'))
                    next = act('cellwork_requirements', { action: 'finalize', content: requirements });
                else if (/split/i.test(subject)) {
                    if (!wire.toolResults.some(t => t.includes('ACCEPTED')))
                        next = act('cellwork_split', { action: 'submit', tasks });
                }
                else if (mortality && /QA worker (Alpha|Beta)/.test(subject)) {
                    const recovery = prompts.some(s => s.includes('QA-RECOVERY'));
                    if (recovery && mode === 'persistent-error') {
                        snapshots.push({ event: 'provider-still-unavailable-on-wake', id, observedAt: new Date().toISOString(), board: boards().map(redactBoard) });
                        res.writeHead(401, { 'content-type': 'application/json' });
                        res.end(JSON.stringify({ error: { type: 'authentication_error', message: 'QA simulated route unavailability' } }));
                        return;
                    }
                    if (recovery)
                        next = act('agent_teams_task', { action: 'complete', task_id: id, note: 'QA recovered original owner' });
                    else if (!wire.toolResults.some(t => t.includes('attempt')) && !observed.has(id))
                        next = act('agent_teams_task', { action: 'claim', task_id: id });
                    else if (!observed.has(id)) {
                        await delay(subject.endsWith('Beta') ? 1050 : 30);
                        const failed = ['provider-error', 'persistent-error'].includes(mode);
                        observed.add(id);
                        snapshots.push({ event: failed ? 'provider-failure' : 'turn-ended-open-task', id, observedAt: new Date().toISOString(), board: boards().map(redactBoard) });
                        if (failed) {
                            res.writeHead(401, { 'content-type': 'application/json' });
                            res.end(JSON.stringify({ error: { type: 'authentication_error', message: 'QA simulated route unavailability' } }));
                            return;
                        }
                    }
                }
                else
                    next = act('agent_teams_task', { action: 'complete', task_id: id, note: 'QA receipt observed' });
            }
        }
        const i = trace.length + 1;
        trace.push({ i, who: captain ? 'captain' : assignment?.[2] ?? 'idle', decision: next?.name ?? 'text', prompt: prompts.map(s => s.slice(0, 115)).slice(-4), result: wire.toolResults.at(-1)?.slice(0, 650) });
        writeFileSync(temp('trace.json'), JSON.stringify(trace, null, 2));
        writeMessagesSse(res, next ? messagesToolUseEvents('qa_call_' + i, next.name, next.args) : messagesTextEvents('QA acknowledgement.'));
    }
    catch (e) {
        res.writeHead(500);
        res.end();
        console.error(e.message);
    }
});
mkdirSync(join(ws, '.mpd'), { recursive: true });
writeFileSync(join(ws, '.mpd', 'mpd.jsonc'), JSON.stringify({ ...(mode === 'defaults' ? {} : { team: { gate: 'off' }, cellwork: { planning: { analysts: 0 } } }), agentRoutes: Object.fromEntries(['Planner', 'Lead', 'Reviewer', 'Senior Engineer', 'Explorer', 'Researcher'].map(r => [r, { provider: 'deepseek-official', model: 'deepseek-flash' }])) }));
writeFileSync(join(root, mode + '-sandbox.txt'), sandbox);
const install = await installProfile({ sandbox, dshHome, env });
if (install.status !== 0)
    throw Error('isolated profile install failed');
await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
useStubRoute(dshHome, server.address().port);
writeFileSync(temp('overlay.yml'), probeOverlay(resolve('skills/dsh-qa/scripts/lib/cellwork-command-probe.ts'), temp('command.json'), 'receive one isolated worker receipt'));
const fd = openSync(temp('boot.log'), 'w');
const child = spawn('dsh', ['--profile', 'mpd-headless', '--patch', temp('overlay.yml'), 'QA-BOOT-CAPTAIN'], { cwd: ws, env, stdio: ['ignore', fd, fd], timeout: 55000 });
const exit = await new Promise(resolve => child.on('exit', (code, signal) => resolve({ code, signal })));
closeSync(fd);
if (mode === 'restart' && cell()?.captainSessionId && observed.size === 2) {
    resumed = true;
    captainCalls = 0;
    const restartedFd = openSync(temp('resume.log'), 'w');
    const captain = spawn('dsh', ['--profile', 'mpd-headless', '--session-id', cell().captainSessionId, 'QA-BOOT-CAPTAIN resume previous work'], { cwd: ws, env, stdio: ['ignore', restartedFd, restartedFd], timeout: 45000 });
    const restartExit = await new Promise(resolve => captain.on('exit', (code, signal) => resolve({ code, signal })));
    closeSync(restartedFd);
    snapshots.push({ event: 'restart-exit', ...restartExit });
}
await new Promise(resolve => server.close(resolve));
const state = cell();
const sessionRoot = join(dshHome, 'sessions');
const sessions = [];
for (const file of existsSync(sessionRoot) ? scan(sessionRoot, /session\.v[34]\.jsonl(?:\.zstd)?$/) : []) {
    const events = decodeSessionLog(file).text.trim().split('\n').map(l => JSON.parse(l));
    const receipts = [];
    for (const e of events.filter(e => e.type === 'tool/call')) {
        const m = events.filter(r => r.type === 'tool/result').map(r => r.data.message).find(m => m.toolCallId === e.data.callId);
        receipts.push({ tool: e.data.name, id: e.data.callId, action: (typeof e.data.arguments === 'string' ? JSON.parse(e.data.arguments) : e.data.arguments)?.action, task: (typeof e.data.arguments === 'string' ? JSON.parse(e.data.arguments) : e.data.arguments)?.task_id, isError: m?.isError, text: m?.content?.map(c => c.text).join('').slice(0, 2200) });
    }
    sessions.push({ id: file.split('/').at(-2), receipts, turnEnds: events.filter(e => e.type === 'turn/end').map(e => ({ at: e.time ?? e.at, reason: e.data?.reason })), errors: events.filter(e => e.type === 'turn/error' || e.type === 'error').map(e => String(e.data?.message ?? e.data?.error?.message ?? '').slice(0, 160)) });
}
const result = { mode, exit, snapshots, sequence, isolation: isolationStep(dshHome, sandbox, 'v2-spawn'), state, boards: boards().map(redactBoard), sessions, journal: state ? readFileSync(join(recordDir, state.cellId, 'journal.jsonl'), 'utf8').trim().split('\n').map(l => JSON.parse(l)) : [], trace };
writeFileSync(join(root, mode + '-result.json'), JSON.stringify(result, null, 2));
const relevant = result.boards.flatMap(b => b.tasks).filter(t => t.subject.startsWith('QA '));
const expected = mode === 'persistent-error' ? 'in_progress' : 'completed';
const ownerReceipts = relevant.every(t => { const member = result.boards.flatMap(b => b.members).find(m => m.name === t.owner || m.executorRef === t.owner); return sessions.find(s => s.id === member?.executorRef)?.receipts.some(r => r.tool === 'agent_teams_task' && r.isError === false && r.text.includes(t.id)); });
const passed = exit.code === 0 && result.isolation.ok && relevant.length === 2 && relevant.every(t => t.status === expected) && ownerReceipts && (!mortality || observed.size === 2) && (!(mode === 'loop-fault') || snapshots.some(s => s.event === 'partial-before-retry'));
console.log(JSON.stringify({ passed, mode, phase: state?.phase, team: state?.teamId, rows: relevant, report: mode + '-result.json' }));
process.exitCode = passed ? 0 : 1;

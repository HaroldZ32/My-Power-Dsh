import assert from 'node:assert/strict'
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { resolve, join } from 'node:path'
import { spawnSync } from 'node:child_process'
const root = resolve('.qa-v2-spawn')
for (const key of ['HOME', 'DSH_HOME', 'TMPDIR']) assert(process.env[key]?.startsWith(root + '/'), key + ' must be isolated')
const family = join(process.env.BASELINE, 'packages/mpd-cellwork-plugin')
const original = readFileSync(join(family, 'test/reseed-binding.test.ts'), 'utf8')
const slice = original.indexOf('// ── A1: the three surfaces name the fresh handle')
assert(slice > 0, 'expected the base fixture boundary at the current revision')
let fixture = original.slice(0, slice).replaceAll('from "../src/', 'from "../packages/mpd-cellwork-plugin/src/').replaceAll('from "../../mpd-dsh-adapter-plugin/', 'from "../packages/mpd-dsh-adapter-plugin/')
function replaceOnce(from, to) {
  assert.equal(fixture.split(from).length, 2, 'fixture drift at ' + from)
  fixture = fixture.replace(from, to)
}
// Change only the copied TEST fixture's team service. The mounted protocol comes from the original checkout.
replaceOnce('if (name === "mpdTeams") {', 'if (name === "mpdWorktree") return { cwdForMember: (_exec, ref) => { lookupIds.push(ref.teamId); return undefined } };\n        if (name === "mpdTeams") {')
replaceOnce('get: (): unknown => {\n              // A19', `active: () => recordOnDisk(),
            list: () => [recordOnDisk(), JSON.parse(readFileSync(join(recordDir, PLANNING_ID + '.json'), 'utf8'))],
            get: (_ws: string, id: string): unknown => {
              if(id===PLANNING_ID) return JSON.parse(readFileSync(join(recordDir, PLANNING_ID + '.json'), 'utf8'))
              if(id!==TEAM_ID) return undefined
              // A19`)
const addition = `
const PLANNING_ID = 'team-planning-004'
const lookupIds: string[] = []
for (const arm of ['single','stale','duplicate']) {
  const stale = arm !== 'single'
  const duplicate = arm === 'duplicate'
  test(arm, async () => {
    lookupIds.length = 0
    const h = makeHarness({team:{...teamRecord(), leadSessionId:CAPTAIN_SESSION, name:'cell '+CELL_ID+' execution'}})
    const planning = duplicate ? { ...teamRecord(), teamId: PLANNING_ID, name:'cell '+CELL_ID+' execution duplicate', leadSessionId:CAPTAIN_SESSION } : { ...teamRecord([]), teamId: PLANNING_ID, phase: 'ended', endedAt: '2026-11-11T00:01:00Z', tasks: [] }
    writeFileSync(join(dirname(h.recordPath), PLANNING_ID+'.json'), JSON.stringify(planning))
    const cell = readCell(h.workspace, CELL_ID)
    if (!cell.ok) throw Error(cell.detail)
    writeCell(h.workspace, { ...cell.state, teamId: stale ? PLANNING_ID : TEAM_ID, planningTeamId: PLANNING_ID, activatedTasks: { fixture: 'T1' } })
    await stopListener(h)({ agent: h.member })
    const member = cellMember(h)
    const execution = h.record()
    const failed = journalRows(h).find(r=>r.event==='checkpoint-unrecoverable')
    const moved = journalRows(h).find(r=>r.event==='compaction'&&r.outcome==='reseeded')
    const owner = execution.tasks.find(t=>t.id==='T1')
    const observation = { arm, recordedTeam:stale?PLANNING_ID:TEAM_ID, worktreeResolution:lookupIds.slice(), executionTeam:TEAM_ID, executionMode:execution.members[0].mode, executionHandle:execution.members[0].executorRef, owner:owner?.owner, taskStatus:owner?.status, attempt:owner?.attempt, cellFenced:member.fenced??false, cellMode:member.mode, replacement:h.activations[0], failure:failed?.reason, surface:failed?.surface, reseeded:!!moved }
    console.log('RESEED_RECEIPT '+JSON.stringify(observation))
    if(!duplicate)expect(lookupIds).toContain(TEAM_ID)
    expect(h.activations.length).toBe(duplicate?0:1)
    expect(observation.owner).toBe(duplicate?OLD_HANDLE:NEW_HANDLE)
    expect(observation.reseeded).toBe(!duplicate)
    if(duplicate)expect(failed?.surface).toBe('team-ownership-ambiguous')
    else {expect(observation.replacement.disposed).toBe(false);expect(observation.cellFenced).toBe(false)}
  })
}
`
const destination = join(root, 'legacy-reseed.test.ts')
mkdirSync(root,{recursive:true})
writeFileSync(destination, fixture + addition)
const run = spawnSync(process.env.PINNED_BUN || 'bun', ['test', './.qa-v2-spawn/legacy-reseed.test.ts'], {encoding:'utf8',env:process.env})
process.stdout.write(run.stdout ?? '')
process.stderr.write(run.stderr ?? '')
process.exitCode = run.status ?? 1

import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { spawn } from 'node:child_process';
import { createServer } from 'node:http';
import { closeSync, existsSync, mkdirSync, openSync, readFileSync, readdirSync, writeFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { setTimeout as delay } from 'node:timers/promises';
import { pathToFileURL } from 'node:url';
const [repoArg, mode] = process.argv.slice(2);
const repo = resolve(repoArg);
const scratch = resolve('.qa-team-t11');
for (const key of ['HOME', 'TMPDIR', 'DSH_HOME'])
    assert(process.env[key]?.startsWith(scratch + '/'), key + ' must be isolated');
const modules = path => import(pathToFileURL(join(repo, 'skills/dsh-qa/scripts', path)));
const { createSandbox, installProfile, useStubRoute, isolationStep } = await modules('extension-isolation.ts');
const { readWireRequest, messagesToolUseEvents, messagesTextEvents, writeMessagesSse } = await modules('lib/messages-sse.ts');
const { decodeSessionLog } = await modules('lib/session-evidence.ts');
const fixture = createSandbox('team-' + mode), { sandbox, dshHome, ws, env } = fixture;
const subject = ['QA criteria', 'QA left review', 'QA right review', 'QA integration'];
const seats = ['criteria-seat', 'left-seat', 'right-seat', 'join-seat'];
const members = seats.map((name, i) => ({ name, description: name, role: 'Senior Engineer', prompt: 'QA participant ' + i + '. Follow the assigned task.' }));
const row = (i, kind, refs, independent = false) => ({ subject: subject[i], description: 'Observe assigned QA ticket ' + i, owner: seats[i], kind, blocked_by: refs, ...(independent ? { independent: true } : {}), ...(['work', 'integration'].includes(kind) ? { write_scopes: ['fixture-' + i + '.txt'] } : {}) });
const flat = [row(0, 'requirement', []), row(1, 'review', []), row(2, 'review', [])];
const fork = [flat[0], row(1, 'review', [subject[0]]), row(2, 'review', [subject[0]]), row(3, 'integration', [subject[1], subject[2]])];
const parallel = mode === 'independent' ? flat.map(t => ({ ...t, independent: true })) : [];
const fn = (tool, args, label) => ({ tool, args, label });
const plan = (action, extra = {}, label = action) => fn('agent_teams_plan', { action, ...extra }, label);
const step = [plan('create', { name: 'QA task graph', description: 'Exercise dependency admission', approval: 'required' })];
if (['baseline', 'repair', 'independent'].includes(mode)) {
    step.push(plan('edit', { members: mode === 'repair' ? members : members.slice(0, 3), tasks: mode === 'independent' ? parallel : flat }, 'flat-edit'), plan('approve', { dry_run: true }, 'initial-preview'), plan('approve', {}, 'initial-approve'));
    if (mode === 'repair')
        step.push(plan('edit', { tasks: fork }, 'fork-edit'), plan('approve', {}, 'fork-approve'), fn('agent_teams_task', { action: 'claim', task_id: 'T4' }, 'premature-claim'));
}
else {
    step.push(...members.slice(0, 2).map(member => plan('add_member', { member })));
    const inputs = mode === 'incremental-review' ? [row(0, 'work', []), row(1, 'review', [])] : [row(0, 'work', []), row(1, 'work', [])];
    for (const task of inputs)
        step.push(plan('create_task', { task }));
    step.push(plan('approve', { dry_run: true }, 'initial-preview'), plan('approve', {}, 'initial-approve'));
}
const sessionDir = join(dshHome, 'sessions'), boardDir = join(ws, '.mpd/team/teams');
const files = dir => existsSync(dir) ? readdirSync(dir, { recursive: true }) : [];
const json = f => JSON.parse(readFileSync(f, 'utf8'));
const boards = () => files(boardDir).filter(f => f.endsWith('.json')).map(f => json(join(boardDir, f)));
const stores = () => files(sessionDir).filter(f => /session\.v[34]\.jsonl(\.zstd)?$/.test(f));
const snapshots = [];
let last = null, index = 0, dispatches = 0, callId = 0, done = false, extra = false, goalClosed = false;
const server = createServer(async (req, res) => {
    try {
        let body = '';
        for await (const part of req)
            body += part;
        const wire = readWireRequest(body);
        const prompts = wire.messages.filter(m => m.role === 'user').flatMap(m => typeof m.content === 'string' ? [m.content] : (m.content || []).filter(b => b.type === 'text').map(b => b.text));
        const root = prompts.includes('QA-T11-CAPTAIN') && !prompts.some(s => s.startsWith('You are a team member.'));
        const assigned = prompts.map(s => s.match(/You have been assigned shared task (\w+): ([^\n]+)/)).filter(Boolean).at(-1);
        const records = boards();
        const board = records.at(-1);
        let next;
        if (root && wire.toolNames.length) {
            if (last) {
                snapshots.push({ label: last.label, tool: last.tool, reply: wire.toolResults.at(-1)?.slice(0, 4400), sessionCount: stores().length, teamRecordCount: records.length, boardRows: board?.tasks.map(t => ({ id: t.id, kind: t.kind, blockedBy: t.blockedBy, status: t.status, revision: t.revision })) ?? [] });
                last = null;
            }
            if (index < step.length)
                next = step[index++];
            else if (mode !== 'baseline' && mode !== 'incremental-review' && board && board.tasks.some(t => t.status !== 'completed') && dispatches < 12) {
                await delay(200);
                next = fn('agent_teams_dispatch', { action: 'run' }, 'dispatch-' + (++dispatches));
            }
            else if (mode === 'repair' && !extra && board?.tasks.every(t => t.status === 'completed')) {
                extra = true;
                next = fn('agent_teams_task', { action: 'depend', task_id: 'T4', blocked_by: ['T1'] }, 'terminal-depend');
            }
            else if (mode === 'append' && !extra && board?.tasks.every(t => t.status === 'completed')) {
                extra = true;
                next = plan('create_task', { task: { subject: 'QA follow-up review', description: 'Independently check both final results', owner: board.members[0].name, kind: 'review', blocked_by: ['T1', 'T2'] } }, 'live-append');
            }
            else if (board && !goalClosed) {
                goalClosed = true;
                next = fn('mpd_goal_finish', { outcome: 'complete' }, 'qa-goal-complete');
            }
            else
                done = true;
            last = next ?? null;
        }
        else if (assigned && wire.toolNames.length) {
            const id = assigned[1];
            const task = board?.tasks.find(t => t.id === id);
            if (task && task.status !== 'completed')
                next = fn('agent_teams_task', { action: 'complete', task_id: id, note: 'QA owner receipt' }, 'complete');
        }
        writeMessagesSse(res, next ? messagesToolUseEvents('t11_' + (++callId), next.tool, next.args) : messagesTextEvents('QA acknowledgement.'));
    }
    catch (e) {
        res.writeHead(500);
        res.end();
        console.error(e.message);
    }
});
mkdirSync(join(ws, '.mpd'), { recursive: true });
writeFileSync(join(ws, '.mpd/mpd.jsonc'), JSON.stringify({ team: { gate: 'off' }, agentRoutes: { 'Senior Engineer': { model: 'deepseek-flash', provider: 'deepseek-official' } } }));
const install = await installProfile({ sandbox, dshHome, env });
assert.equal(install.status, 0, install.out);
await new Promise(r => server.listen(0, '127.0.0.1', r));
useStubRoute(dshHome, server.address().port);
const graphFile = join(sandbox, 'graph.json'), overlay = join(sandbox, 'graph.yml');
writeFileSync(overlay, `- insert:\n    - id: mpd-team-graph-qa-reader\n      name: ${JSON.stringify(join(scratch, 'graph-probe.mjs'))}\n      config:\n        workspace: ${JSON.stringify(ws)}\n        out: ${JSON.stringify(graphFile)}\n`);
const fd = openSync(join(sandbox, 'boot.log'), 'w');
const child = spawn('dsh', ['--profile', 'mpd-headless', '--patch', overlay, 'QA-T11-CAPTAIN'], { cwd: ws, env, stdio: ['ignore', fd, fd], timeout: 45000 });
const exit = await new Promise(r => child.on('exit', (code, signal) => r({ code, signal })));
closeSync(fd);
await new Promise(r => server.close(r));
const records = boards();
const logs = stores().map(f => { const events = decodeSessionLog(join(sessionDir, f)).text.trim().split('\n').map(JSON.parse); return { id: dirname(f).split('/').at(-1), calls: events.filter(e => e.type === 'tool/call').map(e => { const msg = events.find(x => x.type === 'tool/result' && x.data.message.toolCallId === e.data.callId)?.data?.message; const a = typeof e.data.arguments === 'string' ? JSON.parse(e.data.arguments) : e.data.arguments; return { callId: e.data.callId, tool: e.data.name, action: a.action, task: a.task_id, isError: msg?.isError, result: msg?.content?.map(x => x.text).join('').slice(0, 3300) }; }) }; });
const compact = { mode, sha256: createHash('sha256').update(readFileSync(join(repo, 'packages/mpd-team-core-plugin/dist/index.js'))).digest('hex'), exit, done, isolation: isolationStep(dshHome, sandbox, mode).ok, snapshots, boards: records.map(b => ({ id: b.teamId, members: b.members.map(m => ({ name: m.name, handle: m.executorRef })), tasks: b.tasks.map(t => ({ id: t.id, subject: t.subject, owner: t.owner, kind: t.kind, status: t.status, revision: t.revision, blockedBy: t.blockedBy })) })), graph: existsSync(graphFile) ? json(graphFile) : null, logs };
writeFileSync(join(scratch, mode + '.json'), JSON.stringify(compact, null, 2));
console.log(JSON.stringify({ mode, exit, root: logs.find(s => s.id.startsWith('session-'))?.calls.map(c => [c.action, c.result?.slice(0, 170)]), graph: compact.graph, counts: snapshots.filter(s => s.label === 'initial-approve').map(s => [s.teamRecordCount, s.sessionCount]) }));

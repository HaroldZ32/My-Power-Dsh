import assert from 'node:assert/strict';
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { join } from 'node:path';
const modes = ['baseline', 'repair', 'independent', 'incremental-review', 'generic', 'append'];
const expectedEdges = [['T1', 'T2'], ['T1', 'T3'], ['T2', 'T4'], ['T3', 'T4']];
const cases = {};
for (const mode of modes) {
    const input = JSON.parse(readFileSync('.qa-team-t11/' + mode + '.json', 'utf8'));
    assert.equal(input.exit.code, 0);
    assert(input.done && input.isolation);
    const cap = input.logs.find(s => s.id.startsWith('session-'));
    assert(cap);
    const b = input.boards[0];
    const result = (label) => input.snapshots.find(s => s.label === label);
    const approval = result('initial-approve');
    assert(approval);
    const matches = (label, rx) => assert.match(result(label).reply, rx);
    const receipts = input.logs.filter(s => s !== cap).flatMap(s => s.calls.map(c => ({ owner: s.id, ...c }))).filter(c => c.tool === 'agent_teams_task' && c.action === 'complete');
    for (const r of receipts) {
        assert.equal(r.isError, false);
        const owner = b.tasks.find(t => t.id === r.task).owner;
        assert.equal(r.owner, b.members.find(m => m.name === owner).handle);
        assert.match(r.result, /completed \(by owner/);
    }
    if (mode === 'baseline') {
        assert.equal(approval.teamRecordCount, 1);
        assert.equal(approval.sessionCount, 4);
        assert.deepEqual(input.graph.edges, []);
        assert(b.tasks.every(t => t.kind === 'work'));
    }
    if (['repair', 'incremental-review'].includes(mode)) {
        for (const label of ['initial-preview', 'initial-approve']) {
            const s = result(label);
            assert.equal(s.teamRecordCount, 0);
            assert.equal(s.sessionCount, 1);
            for (const text of ['all-root', 'independent: true', 'blocked_by', 'QA criteria', 'QA left review'])
                assert(s.reply.includes(text));
            if (mode === 'repair')
                assert(s.reply.includes('QA right review'));
        }
    }
    if (mode === 'repair') {
        assert.deepEqual(input.graph.edges, expectedEdges);
        assert.deepEqual(input.graph.nodes.map(n => n.depth), [0, 1, 1, 2]);
        assert.deepEqual(b.tasks.map(t => t.kind), ['requirement', 'review', 'review', 'integration']);
        assert.deepEqual(b.tasks.map(t => t.blockedBy), [[], ['T1'], ['T1'], ['T2', 'T3']]);
        matches('premature-claim', /BLOCKED by T2.*T3/);
        matches('terminal-depend', /completed.*frozen/);
        const before = input.snapshots[input.snapshots.findIndex(s => s.label === 'terminal-depend') - 1];
        assert.deepEqual(before.boardRows, result('terminal-depend').boardRows);
        const waves = input.snapshots.filter(s => s.label.startsWith('dispatch') && s.reply.includes(' -> ')).map(s => s.reply.split('\n').map(line => line.split(' -> ')[0]));
        assert.deepEqual(waves, [['QA criteria'], ['QA left review', 'QA right review'], ['QA integration']]);
        assert.equal(receipts.length, 4);
    }
    if (mode === 'independent') {
        assert.equal(approval.teamRecordCount, 1);
        assert.equal(approval.sessionCount, 4);
        assert.deepEqual(input.graph.edges, []);
        assert.equal(receipts.length, 3);
        assert.equal(result('dispatch-1').reply.split(' -> ').length - 1, 3);
        assert(!approval.reply.includes('WARNING'));
    }
    if (['append', 'generic'].includes(mode)) {
        for (const label of ['initial-preview', 'initial-approve'])
            matches(label, /WARNING:.*all-root.*QA criteria.*QA left review.*independent: true/s);
        assert.equal(approval.teamRecordCount, 1);
        assert.equal(approval.sessionCount, 3);
    }
    if (mode === 'append') {
        assert.equal(b.tasks[2].kind, 'review');
        assert.deepEqual(b.tasks[2].blockedBy, ['T1', 'T2']);
        assert.deepEqual(input.graph.edges, [['T1', 'T3'], ['T2', 'T3']]);
        assert.equal(receipts.length, 3);
    }
    const planLabels = new Set(['initial-approve', 'initial-preview', 'fork-approve', 'premature-claim', 'terminal-depend', 'live-append']);
    const actions = input.snapshots.filter(s => planLabels.has(s.label) || s.label.startsWith('dispatch') && s.reply.includes(' -> '));
    cases[mode] = { artifactSha256: input.sha256, isolated: true, headlessExit: input.exit.code, captainSession: cap.id, receipts: actions.map(s => { const r = cap.calls.find(c => c.result === s.reply); assert(r); return { stage: s.label, callId: r.callId, isError: r.isError, text: r.result.split('\n  senior-engineer-')[0] + (s.label === 'initial-approve' && r.result.includes('WARNING:') && !r.result.split('\n  senior-engineer-')[0].includes('WARNING:') ? '\n' + r.result.slice(r.result.indexOf('WARNING:')) : ''), sessionCount: s.sessionCount, boardCount: s.teamRecordCount }; }), board: b, graph: input.graph, successfulChildReceipts: receipts };
}
const dest = process.argv[2];
mkdirSync(dest, { recursive: true });
writeFileSync(join(dest, 'result.json'), JSON.stringify({ cases }, null, 2) + '\n');
console.log('All six public entry-point cases passed');

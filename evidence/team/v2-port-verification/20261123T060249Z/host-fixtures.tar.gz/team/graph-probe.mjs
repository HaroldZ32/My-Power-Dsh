import { writeFileSync } from 'node:fs';
export const name = 'mpd-team-graph-qa-reader';
export const inject = ['mpdTeams'];
export function apply(ctx, config) {
    ctx.on('agent/pre-step', async (payload, next) => {
        const decision = typeof next === 'function' ? await next() : undefined;
        const teams = ctx.get('mpdTeams');
        const ws = payload.agent?.session?.header?.cwd;
        if (ws && ws === config.workspace) {
            const team = teams.list(ws).at(-1);
            if (team?.teamId) {
                const graph = teams.graph(ws, team.teamId);
                if (graph)
                    writeFileSync(config.out, JSON.stringify({ teamId: team.teamId, nodes: graph.nodes.map(n => ({ id: n.id, depth: n.depth })), edges: graph.edges.map(e => [e.from, e.to]) }));
            }
        }
        return decision;
    });
}
